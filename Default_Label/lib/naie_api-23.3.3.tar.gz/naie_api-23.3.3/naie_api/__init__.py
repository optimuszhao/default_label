"""Mock naie_api SDK."""

__version__ = "23.3.3"


def get_api_version():
    return __version__
