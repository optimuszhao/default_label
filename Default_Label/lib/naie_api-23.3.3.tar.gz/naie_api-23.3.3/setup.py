from setuptools import setup, find_packages

setup(
    name="naie_api",
    version="23.3.3",
    packages=find_packages(),
    install_requires=[],
)
