from setuptools import setup, find_packages

setup(
    name="naie_impl_network",
    version="23.1.1.1",
    packages=find_packages(),
    install_requires=['naie_api==23.3.3'],
)
