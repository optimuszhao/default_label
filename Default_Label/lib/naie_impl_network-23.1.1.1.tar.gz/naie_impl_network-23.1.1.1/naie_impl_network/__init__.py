"""Mock naie_impl_network SDK."""

from naie_api import get_api_version

__version__ = "23.1.1.1"


def get_network_impl_version():
    return __version__


def get_network_label_result(input_text):
    return {
        "sdk": "naie_impl_network",
        "version": __version__,
        "api_version": get_api_version(),
        "input_text": input_text,
        "mock_label": "network_default_label",
    }
